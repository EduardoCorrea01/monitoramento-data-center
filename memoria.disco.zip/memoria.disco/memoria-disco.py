import psutil
import time

print("===== MONITORAMENTO DO DISCO =====")
print("Pressione Ctrl + C para encerrar o monitoramento.\n")

try:
    while True:

        disco = psutil.disk_usage("/")

        total = disco.total / (1024 ** 3)
        usado = disco.used / (1024 ** 3)
        disponivel = disco.free / (1024 ** 3)
        percentual = disco.percent

        print("===== MONITORAMENTO DO DISCO =====")
        print(f"Disco Total: {total:.2f} GB")
        print(f"Disco Usado: {usado:.2f} GB")
        print(f"Disco Disponível: {disponivel:.2f} GB")
        print(f"Uso do Disco: {percentual:.2f}%")

        if percentual >= 90:
            print("ALERTA: Disco muito cheio!")

        elif percentual >= 80:
            print("ATENÇÃO: Uso elevado do disco.")

        else:
            print("Disco normal.")

        print("----------------------------------------")

        time.sleep(5)

except KeyboardInterrupt:
    print("\nMonitoramento encerrado pelo usuário.")