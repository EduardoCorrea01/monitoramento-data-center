# Pulse — Monitoramento do Data Center

Dashboard web responsivo para visualizar telemetria de CPU, memória, disco, disponibilidade e alertas de até quatro servidores.

## Estrutura

- `index.html`: estrutura da interface, indicadores, gráficos e diálogos.
- `styles.css`: tema visual, estados dos componentes e layout responsivo.
- `app.js`: atualização da interface, gráficos, navegação, validação de limites e integração da telemetria.
- `monitoring.js`: validação das leituras, estado de disponibilidade e ciclo de vida dos alertas.

## Interface

A **Visão geral** mostra indicadores, histórico da sessão, armazenamento medido, servidores e alertas. As telas **Servidores**, **Armazenamento** e **Alertas** podem ser abertas pela navegação lateral. O cartão de capacidade planejada foi removido; não confunda os limites configurados no código com métricas coletadas.

Sem telemetria, as métricas aparecem como indisponíveis. O dashboard não cria dados fictícios. O histórico de CPU/memória e os alertas só existem na memória da página e são perdidos ao recarregá-la.

## Configuração deste projeto

Os limites de entrada correspondem à infraestrutura informada:

- Quatro servidores: três servidores e um servidor central.
- RAM planejada: 5 GB no total (1 GB por servidor e 2 GB no central).
- Disco: no máximo 10 GB por servidor e 40 GB no total.
- CPUs: seis vCPUs no total.

Essa capacidade planejada não é exibida como consumo medido no dashboard. Para alterar limites, atualize a configuração `serverLimits` no início de `app.js` e valide as capacidades reais dos servidores antes de ingerir telemetria.

## Integrar telemetria

O navegador disponibiliza `window.receiveServerTelemetry` para ser chamado por código hospedeiro já integrado ao coletor:

```js
window.receiveServerTelemetry({
  serverId: 'servidor-01',
  cpu: 86.2,       // percentual de 0 a 100
  memory: 78.4,    // percentual de 0 a 100
  diskUsed: 8.6,   // GB
  diskTotal: 10    // GB; no maximo 10 GB por servidor
});
```

CPU, memória e disco geram alerta crítico quando ultrapassam 85%. Um servidor sem nova leitura por mais de dois minutos é marcado offline; a verificação ocorre a cada cinco segundos, após sua primeira leitura. O painel só calcula o percentual de disco quando os quatro servidores enviam dados recentes. A média de CPU/memória é calculada entre servidores com sinal e não pondera RAM alocada.

Cada abertura ou resolução de alerta emite o evento de navegador `monitoring-alert`, com os dados do alerta em `event.detail`.

## Prontidão para uso real

**O dashboard ainda não está apto, sozinho, para monitoramento operacional.** `window.receiveServerTelemetry` é uma função JavaScript local, não um endpoint de rede, coletor ou mecanismo autenticado. A página não conecta aos servidores, não persiste dados, não envia notificações externas e deixa de monitorar quando fechada.

Para produção, é necessário implantar um coletor/backend autenticado e protegido, conectar os quatro servidores, configurar armazenamento persistente e alertas externos, e monitorar o próprio coletor. Não exponha a função do navegador como canal público de ingestão.

## Executar e verificar

Abra `index.html` em um navegador com acesso à internet. Bootstrap e Chart.js são carregados por CDN.

Verifique a sintaxe dos scripts com Node.js:

```powershell
node --check app.js
node --check monitoring.js
```

O teste de uso manual feito nesta alteração cobriu carregamento sem dados simulados, navegação, estado sem telemetria, inventário e notificações, agregação de leituras dos quatro servidores, alertas e recuperação, limite de quatro servidores, máximo de 10 GB por disco e layout mobile. Isso valida o dashboard e a função local de entrada; não substitui o teste de ponta a ponta com o coletor real.

## Repositório e publicação

- Código-fonte: [GitHub](https://github.com/gabrielmartins171223-ship-it/data-center-monitoring-system).
- Dashboard no GitHub Pages: [abrir o dashboard](https://gabrielmartins171223-ship-it.github.io/data-center-monitoring-system/#overview).

O GitHub Pages publica somente os arquivos estáticos e não recebe telemetria. Para publicar alterações, faça push para `main`; o workflow [pages.yml](https://github.com/gabrielmartins171223-ship-it/data-center-monitoring-system/blob/main/.github/workflows/pages.yml) publica a interface automaticamente.8

//DOC 

DOSSIÊ TÉCNICO DE FRONT-END
PROJETO INTEGRADOR: SISTEMA INTELIGENTE DE MONITORAMENTO DE DATA CENTER (PULSE)
Instituição: Faculdade Anhanguera
Disciplinas Integradas: Arquitetura de Computadores • Sistemas Distribuídos • Engenharia de Software
Docente Orientador: Prof. Marcio João
Escopo: Interface de Monitoramento Analítico do Data Center (Front-end) 
Membros: Thiago, Ismael, Nicolly, Gabriel, Adrian, Givanilton, Arthur, Pedro, Cleber ,Kauã , isaque,gabriel putov 


1. SUMÁRIO EXECUTIVO E OBJETIVOS DO SISTEMA
Este documento constitui a documentação técnica definitiva e versão final revisada de engenharia de Front-end do Pulse — Monitoramento Data Center. O propósito central deste projeto foi projetar, arquitetar e homologar uma interface web responsiva de alta performance voltada ao acompanhamento operacional, visualização de telemetria em tempo real (CPU, memória, disco, disponibilidade e alertas) de até quatro servidores no Data Center (DC São Paulo 01).

A solução foi desenvolvida de forma desacoplada (decoupled) das camadas de Back-end e Banco de Dados nesta primeira etapa, garantindo total autonomia técnica no processo de validação de usabilidade, estabilidade do Document Object Model (DOM) e eficiência da renderização gráfica via cliente (Chart.js e Bootstrap 5).


2. STACK TECNOLÓGICA E ECOSSISTEMA WEB
A arquitetura do Front-end foi estruturada rigorosamente sob os padrões abertos da W3C (World Wide Web Consortium), garantindo modularidade, legibilidade do código, facilidade de manutenção e compatibilidade cross-browser.
2.1 Descrição Textual da Arquitetura em Camadas
Base de Estruturação e Estilização (index.html, styles.css, Bootstrap 5): O HTML5 semântico fornece a estrutura fundamental do DOM e marcações de acessibilidade ARIA. O CSS3 customizado gerencia o tema visual escuro com paleta em tons pastéis de baixa saturação. O Bootstrap 5 provê o sistema de grid flexível e componentes offcanvas responsivos.
Camada de Lógica e Processamento no Cliente (app.js, monitoring.js): O JavaScript ES6+ atua como motor de lógica de negócios (ServerMonitoringService), realizando a validação de leituras, gerenciamento de ciclos de vida de alertas, controle de servidores offline e integração de telemetria.
Camada de Visualização Analítica (Chart.js Engine): Renderização de gráficos de linha (tendências de CPU e RAM com períodos de 1H, 6H, 24H) e gráficos de rosca (armazenamento em disco) no elemento HTML5 <canvas>.
2.2 Detalhamento dos Componentes Tecnológicos
HTML5 (W3C Standard): Estruturação semântica (<main>, <section>, <header>, <article>, <nav>) e elementos <canvas>.
CSS3 (Cascading Style Sheets - Level 3): Variáveis globais (:root), modelo de caixas (box-sizing), animações de transição e paleta ergonômica.
JavaScript (ES6+ / ECMAScript 2022): Programação assíncrona, manipulação de eventos, manipulação de mapas de servidores e tratamento de payloads de telemetria.
Bootstrap 5: Sistema de grid responsivo, offcanvas e componentes utilitários.
Chart.js 4.4.9: Motor gráfico em canvas para visualização de CPU/RAM e capacidade de armazenamento.


3. CONFIGURAÇÃO DE INFRAESTRUTURA E LIMITES DO SISTEMA
Os limites de entrada correspondem estritamente à infraestrutura modelada no código (serverLimits em app.js e monitoring.js):

Topologia de Servidores: Quatro servidores no total (três servidores padrão e um servidor central no Data Center DC-SP01).
Capacidade de Memória RAM Planejada: 5 GB no total (1 GB por servidor e 2 GB no servidor central).
Armazenamento em Disco: No máximo 10 GB por servidor e 40 GB no total da infraestrutura.
Processamento: Seis vCPUs no total.
Limiar de Alerta: CPU, memória RAM e uso de disco geram alerta crítico quando ultrapassam 85%.
Monitoramento de Disponibilidade (Offline): Um servidor sem nova leitura de telemetria por mais de dois minutos (120.000 ms) é marcado como offline. A verificação ocorre a cada cinco segundos, após sua primeira leitura.


4. INTEGRAÇÃO DE TELEMETRIA E EVENTOS
O sistema disponibiliza globalmente a função window.receiveServerTelemetry para ingestão de dados por código hospedeiro ou coletor integrado:

window.receiveServerTelemetry({

  serverId: 'servidor-01',

  cpu: 86.2,       // percentual de 0 a 100

  memory: 78.4,    // percentual de 0 a 100

  diskUsed: 8.6,   // GB

  diskTotal: 10    // GB; no maximo 10 GB por servidor

});
Eventos de Navegador (monitoring-alert)
Cada abertura ou resolução de alerta emite um evento de navegador customizado (CustomEvent) denominado monitoring-alert, disponibilizando todos os dados do evento em event.detail.
Testes com Dados Mocados (Mock Data)
Nesta seção, destaca-se que estruturas e blocos de dados mocados (mock data) foram amplamente utilizados em conjunto com a função de ingestão para testar as funcionalidades da interface (como renderização de gráficos, atualização de KPIs, comportamento de alertas e inventário de servidores) antes da integração com coletores de rede reais.


5. ENGENHARIA DE UX/UI, ERGONOMIA COGNITIVA E DESIGN SYSTEM
Layout de Fluxo Contínuo Horizontal: Unificação do painel em uma visão panorâmica para eliminar trocas excessivas de abas e reduzir a carga cognitiva (cognitive load) dos operadores no Centro de Operações de Rede (NOC).
Design System e Astenopia Ocupacional: Utilização de tons pastéis de baixa saturação para suavizar a luminância da tela e prevenir o estresse ocular em turnos prolongados de monitoramento.


6. DECLARAÇÃO DO USO DE INTELIGÊNCIA ARTIFICIAL GENERATIVA
Em conformidade com as diretrizes do Projeto Integrador, declara-se o uso de IA Generativa como apoio à formulação estrutural, refinamento de código em JavaScript/Chart.js e padronização da documentação técnica, sob rigoroso ciclo de validação humana (Human-in-the-Loop e Peer Code Review).


7. QUALITY ASSURANCE (QA) E MATRIZ DE TESTES
Nota: Todos os testes de responsividade e adaptação de layout foram realizados diretamente pelo navegador utilizando a aba de ferramentas de teste de resolução (Responsive Design Mode).

ID
Caso de Teste
Requisito Avaliado
Resultado Esperado
Status
T1
Responsividade até 1024px
Ajuste do Grid Bootstrap
Reorganização automática dos cards em telas menores.
Aprovado
T2
Renderização de Gráficos
Inicialização do Chart.js
Exibição correta das curvas de CPU e RAM via canvas.
Aprovado
T3
Ingestão de Telemetria
Função receiveServerTelemetry
Validação de limites (max 4 servidores, 10 GB/disco, 85% alerta).
Aprovado
T4
Timeout e Estado Offline
Verificação a cada 5s
Marcação de servidores offline após 2 minutos sem sinal.
Aprovado
T5
Emissão de Eventos de Alerta
Evento monitoring-alert
Disparo correto de eventos personalizados ao abrir/resolver alertas.
Aprovado
T6
Bloco de Teste de Ingestão
Execução no DOMContentLoaded
Injeção bem-sucedida de telemetria de teste para validação inicial.
Aprovado

Evidências de Testes por Resolução (Resultados dos Testes de Responsividade)
Resolução 540px x 720px:

Validação do comportamento responsivo, quebra de colunas e empilhamento dos elementos principais da interface em telas verticais de menor proporção.
Resultou em sucesso na adaptação do menu offcanvas e disposição dos cartões.
QA Resolution 540x720 [file-tag: drive-uploaded-file-1l-mdFmdZJIK-i6uiDVYFwulQdj34TpOA]

Resolução 600px x 960px:

Validação do menu offcanvas, barras de navegação adaptadas e indicadores de alerta operacionais.
Comprovou estabilidade e legibilidade adequadas para telas intermediárias.
QA Resolution 600x960 [file-tag: drive-uploaded-file-1ndHgL_ytO6DFg-HOFH-FBGd9lY27TLCs]

Resolução 768px x 1024px:

Validação de adaptação em telas de tablets e visualização estruturada em modo retrato (portrait), garantindo estabilidade no grid e nos gráficos analíticos.
QA Resolution 768x1024 [file-tag: drive-uploaded-file-1d49WPJxgFNQy01Z27yOycrF7Qfi4BVPM]


8. CONSIDERAÇÕES FINAIS
A documentação e a implementação do Front-end do Pulse satisfazem  os requisitos acadêmicos e técnicos propostos, integrando conceitos avançados de Arquitetura de Computadores, Sistemas Distribuídos e Engenharia de Software. O sistema encontra-se homologado para integração futura com back-ends autenticados e coletores de rede reais.
